SELECT first_name, last_name, primary_phone, billing_address_1
FROM customers
WHERE ccid = "1";

