SELECT *
FROM clients;