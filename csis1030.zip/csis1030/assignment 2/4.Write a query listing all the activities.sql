SELECT *
FROM activities;