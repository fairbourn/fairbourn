SELECT *
FROM clients