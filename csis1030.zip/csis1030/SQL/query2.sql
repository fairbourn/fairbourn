SELECT first_name, last_name, billing_address_1, primary_phone
FROM customers
WHERE billing_state = "OH";