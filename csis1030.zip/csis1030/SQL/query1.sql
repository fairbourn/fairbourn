SELECT *
FROM customers
ORDER BY last_name;