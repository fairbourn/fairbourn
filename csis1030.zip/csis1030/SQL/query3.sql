SELECT *
FROM roles;